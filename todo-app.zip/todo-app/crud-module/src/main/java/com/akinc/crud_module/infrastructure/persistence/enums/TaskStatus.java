package com.akinc.crud_module.infrastructure.persistence.enums;

public enum TaskStatus {
    CREATED,
    UPDATED,
    COMPLETED,
    CANCELLED
}
