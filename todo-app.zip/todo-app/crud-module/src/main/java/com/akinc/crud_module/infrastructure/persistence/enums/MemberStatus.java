package com.akinc.crud_module.infrastructure.persistence.enums;

public enum MemberStatus {
    ACTIVE,
    DELETED
}
